// src/components/DaftarHarga.js

export const LIST_PAKET = [
  { id: 1, label: '30 Jam', durasi: 30, harga: 3000, tipe: 'JAM' },
  { id: 2, label: '60 Jam', durasi: 60, harga: 5000, tipe: 'JAM' },
  { id: 3, label: 'Paket Hemat', durasi: 24, harga: 2000, tipe: 'JAM' },
  { id: 4, label: '1 Minggu', durasi: 7, harga: 25000, tipe: 'HARI' },
];
