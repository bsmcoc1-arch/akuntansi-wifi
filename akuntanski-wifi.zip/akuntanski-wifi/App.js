import React from 'react';
// Import halaman yang ingin ditampilkan
import HomeScreen from './src/screens/HomeScreen';
import DaftarHarga from './src/components/DaftarHarga';

export default function App() {
  return (
    // Kamu cukup memanggil komponen halaman di sini
    <HomeScreen />
  );
}
